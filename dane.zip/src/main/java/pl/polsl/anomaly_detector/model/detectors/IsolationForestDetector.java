package pl.polsl.anomaly_detector.model.detectors;

import com.github.chen0040.trees.isolation.IsolationForest;

public class IsolationForestDetector extends IsolationForest implements IAnomalyDetector {

    public IsolationForestDetector() {
        super();
    }

}
