package pl.polsl.anomaly_detector.model.detectors;

import com.github.chen0040.lof.LOF;

public class LOFDetector extends LOF implements IAnomalyDetector{

    public LOFDetector() {
        super();
    }
}
