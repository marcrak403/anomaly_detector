package pl.polsl.anomaly_detector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnomalyDetectorApplicationTests {

    @Test
    void contextLoads() {
    }

}
